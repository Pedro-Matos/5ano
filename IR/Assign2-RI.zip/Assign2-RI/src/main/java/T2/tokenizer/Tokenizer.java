package T2.tokenizer;

import java.util.List;

public interface Tokenizer {
    List<String> tokenize(String corpusText);
}
